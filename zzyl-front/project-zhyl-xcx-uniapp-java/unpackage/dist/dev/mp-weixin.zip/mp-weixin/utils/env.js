"use strict";
const baseUrl = "https://zhyl-t.itheima.net/customer";
const notToLoginApiUrl = [];
exports.baseUrl = baseUrl;
exports.notToLoginApiUrl = notToLoginApiUrl;

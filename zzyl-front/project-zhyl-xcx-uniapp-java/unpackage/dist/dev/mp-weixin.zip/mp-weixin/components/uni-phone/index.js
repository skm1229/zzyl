"use strict";
const index = require("../../index2.js");
require("../../common/vendor.js");
require("../../utils/index.js");
wx.createPage(index.MiniProgramPage);

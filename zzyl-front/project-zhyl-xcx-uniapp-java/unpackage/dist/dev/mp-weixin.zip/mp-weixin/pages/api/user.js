"use strict";
require("../../common/vendor.js");

"use strict";
const PickerView = require("../../../PickerView.js");
require("../../../common/vendor.js");
require("../../../utils/index.js");
wx.createPage(PickerView.MiniProgramPage);
